(function() {
  test.coffee;

}).call(this);
