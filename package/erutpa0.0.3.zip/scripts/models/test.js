(function() {
  define([], function() {
    return {
      test: "foo"
    };
  });

}).call(this);
