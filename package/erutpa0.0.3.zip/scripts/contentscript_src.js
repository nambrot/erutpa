(function() {
  require(['models/test', 'jquery'], function(test, jquery) {
    return console.log(test);
  });

}).call(this);
